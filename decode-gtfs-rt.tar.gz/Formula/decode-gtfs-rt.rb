class DecodeGtfsRt < Formula
  desc "Decodes GTFS-RT feeds and saves as human-readable JSON"
  homepage "https://github.com/colemccarren/homebrew-decode-gtfs-rt"
  url "https://github.com/colemccarren/homebrew-decode-gtfs-rt/archive/refs/tags/v1.0.0.tar.gz"
  sha256 "<SHA256_HASH>" # Replace this with the actual hash

  depends_on "protobuf"

  def install
    bin.install "decode_gtfs_rt.sh"
  end

  test do
    system "#{bin}/decode_gtfs_rt.sh", "--help"
  end
end

